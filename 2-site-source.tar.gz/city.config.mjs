export const ACTIVE_CITY = 'sylvania-oh';
