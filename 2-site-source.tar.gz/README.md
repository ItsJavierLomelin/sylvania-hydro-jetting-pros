# Sylvania Hydro Jetting Pros

Astro source built from webflow-plumber-128-site-template. Preview only.

All copy and settings: src/data/cities/sylvania-oh.json
City selector: city.config.mjs
Build: npm ci && npm run build

Local source: https://sylvaniaadvantage.com/2023/04/04/sylvania-then-now/

The documented city area is retained; no extra neighborhood pages were invented.
